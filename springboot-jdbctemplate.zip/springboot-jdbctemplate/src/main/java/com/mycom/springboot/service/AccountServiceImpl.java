package com.mycom.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mycom.springboot.dao.IAccountDao;
import com.mycom.springboot.model.Account;

@Service
public class AccountServiceImpl implements IAccountService {
	@Autowired
    private final IAccountDao dao;

    public AccountServiceImpl() {
		this.dao = null;
    	
    }
    public AccountServiceImpl(IAccountDao dao) {
        //this.dao = null;
		this.dao = dao;
    }

    @Override
    public void create(Account account) {
        dao.createAccount(account);
        System.out.println("Account created successfully!");
    }
    @Override
    public Account getById(int id) {
        return dao.getAccountById(id);
    }
    @Override
    public List<Account> getAll() {
        return dao.getAllAccounts();
    }
    @Override
    public void update(Account account) {
        dao.updateAccount(account);
        System.out.println("Account updated successfully!");
    }
    @Override
    public void delete(int id) {
        dao.deleteAccount(id);
        System.out.println("Account deleted successfully!");
    }
}