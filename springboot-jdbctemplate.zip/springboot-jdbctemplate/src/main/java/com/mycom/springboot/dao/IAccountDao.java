package com.mycom.springboot.dao;

import java.util.List;

import com.mycom.springboot.model.Account;

public interface IAccountDao {

    int createAccount(Account account);

    Account getAccountById(int id);

    List<Account> getAllAccounts();

    int updateAccount(Account account);

    int deleteAccount(int id);
}