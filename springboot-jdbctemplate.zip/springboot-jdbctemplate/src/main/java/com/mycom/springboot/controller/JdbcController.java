package com.mycom.springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;  
@RestController  
public class JdbcController {  
    @Autowired  
    JdbcTemplate jdbc;   
    
    @RequestMapping("/insert")  
    public String addRow(){  
        jdbc.execute("insert into account values(333,'Kumar',50000.00)");  
        return"Data has been inserted Successfully";  
    }  
}  