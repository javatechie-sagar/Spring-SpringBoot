package com.mycom.springboot.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Repository;

import com.mycom.springboot.model.Account;

//DAO layer
@Repository
public class AccountDaoImpl implements IAccountDao {

    private final JdbcTemplate jdbcTemplate;

    public AccountDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public int createAccount(Account account) {
    	System.out.println(account.getName());
        String sql = "INSERT INTO account(id,name,balance) VALUES(?, ?, ?)";

        return jdbcTemplate.update(
                sql,
                account.getId(),
                account.getName(),
                account.getBalance()
        );
    }

    @Override
    public Account getAccountById(int id) {

        String sql = "SELECT * FROM account WHERE id=?";

        return jdbcTemplate.queryForObject(
                sql,
                new BeanPropertyRowMapper<>(Account.class),
                id
        );
    }

    @Override
    public List<Account> getAllAccounts() {

        String sql = "SELECT * FROM account";

        return jdbcTemplate.query(
                sql,
                new BeanPropertyRowMapper<>(Account.class)
        );
    }

    @Override
    public int updateAccount(Account account) {

        String sql = "UPDATE account SET name=?, balance=? WHERE id=?";

        return jdbcTemplate.update(
                sql,
                account.getName(),
                account.getBalance(),
                account.getId()
        );
    }

    @Override
    public int deleteAccount(int id) {

        String sql = "DELETE FROM account WHERE id=?";

        return jdbcTemplate.update(sql, id);
    }
}