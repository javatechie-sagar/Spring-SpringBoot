package com.mycom.springboot.service;

import java.util.List;

import com.mycom.springboot.model.Account;

public interface IAccountService {
	 void create(Account account);

	    Account getById(int id);

	    List<Account> getAll();

	    void update(Account account);

	    void delete(int id);
}
