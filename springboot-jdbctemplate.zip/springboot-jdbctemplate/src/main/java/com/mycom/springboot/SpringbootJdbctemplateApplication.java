package com.mycom.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorMvcAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
@EnableAutoConfiguration(exclude = {ErrorMvcAutoConfiguration.class})
@ComponentScan(basePackages={"com.mycom.springboot.controller,"
		+ "com.mycom.springboot.service,com.mycom.springboot.dao"})
public class SpringbootJdbctemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootJdbctemplateApplication.class, args);
		System.out.println("Spring Boot Application Started..!");
	}

}
