package com.mycom.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mycom.springboot.model.Account;
import com.mycom.springboot.service.AccountServiceImpl;

@RestController
@RequestMapping("/accounts")
public class AccountController {
	@Autowired
    private final AccountServiceImpl service;

    public AccountController(AccountServiceImpl service) {
        this.service = service;
    }

    // CREATE
    @PostMapping
    public String createAccount(@RequestBody Account account) {
    	service.create(account);
        return "Account created successfully!";
    }
    // READ BY ID
    @GetMapping("/{id}")
    public Account getAccount(@PathVariable int id) {
        return service.getById(id);
    }
    // READ ALL
    @GetMapping
    public List<Account> getAllAccounts() {
        return service.getAll();
    }
    // UPDATE
    @PutMapping
    public String updateAccount(@RequestBody Account account) {
        service.update(account);
        return "Account updated successfully!";
    }
    // DELETE
    @DeleteMapping("/{id}")
    public String deleteAccount(@PathVariable int id) {
        service.delete(id);
        return "Account deleted successfully!";
    }
}