package com.mycom.springboot.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mycom.springboot.model.Product;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/products")
@Tag(name = "Product API", description = "CRUD operations on Product")
public class ProductController {

    private List<Product> list = new ArrayList<>();

    @Operation(summary = "Get all products")
    @GetMapping
    public List<Product> getAllProducts() {
        return list;
    }
    @Operation(summary = "Add a new product")
    @PostMapping
    public Product addProduct(@RequestBody Product product) {
        list.add(product);
        return product;
    }
    @Operation(summary = "Get product by id")
    @GetMapping("/{id}")
    public Product getProductById(@PathVariable int id) {
        for (Product p : list) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null; // or throw exception
    }
    @Operation(summary = "Update product by id")
    @PutMapping("/{id}")
    public Product updateProduct(@PathVariable int id,
                                 @RequestBody Product product) {
        for (int i = 0; i < list.size(); i++) {
            Product p = list.get(i);
            if (p.getId() == id) {
                p.setName(product.getName());
                p.setPrice(product.getPrice());
                return p;
            }
        }
        return null;
    }  
    @Operation(summary = "Delete product by id")
    @DeleteMapping("/{id}")
    public String deleteProduct(@PathVariable int id) {

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId() == id) {
                list.remove(i);
                return "Product deleted successfully";
            }
        }
        return "Product not found";
    }
}
