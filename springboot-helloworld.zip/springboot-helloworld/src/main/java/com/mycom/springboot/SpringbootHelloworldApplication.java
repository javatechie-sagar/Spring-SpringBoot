package com.mycom.springboot;

//import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorMvcAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableAutoConfiguration(exclude = {ErrorMvcAutoConfiguration.class})
@ComponentScan(basePackages={"com.mycom.springboot.controller"})

public class SpringbootHelloworldApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SpringbootHelloworldApplication.class, args);
		System.out.println("Welcome to Spring Boot!");
	}
	

	// CommandLine Runner
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Spring Boot Application Runner has started!");
		
	}


	/*
	 * // Application Runner public void run(ApplicationArguments args) throws
	 * Exception { // TODO Auto-generated method stub
	 * System.out.println("Spring Boot Command Line Runner  has started!");
	 * 
	 * }
	 */






}
