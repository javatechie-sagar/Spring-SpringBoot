package com.mycom.springboot.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
	@GetMapping("/hello")
	// http://localhost:8087/hello
	public String showHello(){
		return "Hello World! Welcome to Spring Boot!";
	}
}
