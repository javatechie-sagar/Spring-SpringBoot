package com.mycom.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@SpringBootApplication
public class SpringbootLoggingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootLoggingApplication.class, args);
		System.out.println("Spring boot application started...!");
		
		Logger logger = LoggerFactory.getLogger(SpringbootLoggingApplication.class);
		
		logger.info("Info level - Hello Logback");
		logger.error("Error level - Hello Logback");
	}

}
