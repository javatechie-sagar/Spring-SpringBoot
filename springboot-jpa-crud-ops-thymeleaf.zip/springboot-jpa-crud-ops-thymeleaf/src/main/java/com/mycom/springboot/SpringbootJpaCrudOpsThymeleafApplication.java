package com.mycom.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorMvcAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages={"com.mycom.springboot"})
@EnableAutoConfiguration(exclude = {ErrorMvcAutoConfiguration.class})

//,"com.mycom.springboot.repository","com.mycom.springboot.model"
public class SpringbootJpaCrudOpsThymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootJpaCrudOpsThymeleafApplication.class, args);
		System.out.println("Spring Boot for JPA & Thymeleaf Started..!");
	}

}
