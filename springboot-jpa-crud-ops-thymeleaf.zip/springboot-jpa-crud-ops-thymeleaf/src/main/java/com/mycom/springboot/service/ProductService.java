package com.mycom.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mycom.springboot.model.Product;
import com.mycom.springboot.repository.IProductRepository;
 @Service
@Transactional
public class ProductService {
     @Autowired
    private IProductRepository repo;
    public List<Product> listAll() {
        return (List<Product>) repo.findAll();
    }
      public void saveProduct(Product product) {
        repo.save(product);
    }
    public Product getProductById(int id) {
        return repo.findById(id).get();
    }
    public void deleteProduct(int id) {
        repo.deleteById(id);
    }
}