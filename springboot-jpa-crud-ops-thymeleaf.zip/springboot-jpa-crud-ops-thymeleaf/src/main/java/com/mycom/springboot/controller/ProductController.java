package com.mycom.springboot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mycom.springboot.model.Product;
import com.mycom.springboot.service.ProductService;

@Controller
@RequestMapping("/products")
public class ProductController {

    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }
    // READ
    @GetMapping
    public String viewHomePage(Model model) {
        model.addAttribute("listProducts", service.listAll());
        return "index";// index.html
    }
    // CREATE - form
    @GetMapping("/new")
    public String showNewProductForm(Model model) {
        model.addAttribute("product", new Product());
        System.out.println("In products/new");
        return "new_product";// new_product.html
    }
    // CREATE / UPDATE
    @PostMapping("/save")
    public String saveProduct(@ModelAttribute("product") Product product) {
        service.saveProduct(product);
        return "redirect:/index.html";
    }
    // UPDATE - form
    @GetMapping("/edit/{id}")
    public String showEditProductForm(@PathVariable int id, Model model) {
        model.addAttribute("product", service.getProductById(id));
        return "edit_product";
    }
    // DELETE
    @GetMapping("/delete/{id}")
    public String deleteProduct(@PathVariable int id) {
        service.deleteProduct(id);
        return "redirect:/products";
    }
}






















//package com.mycom.springboot.controller;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.servlet.ModelAndView;
//
//import com.mycom.springboot.model.Product;
//import com.mycom.springboot.service.ProductService;
//
//@RestController
//public class ProductController {
//
//	@Autowired
//	private ProductService productService; 
//	// Home page - localhost:8087/
//	@RequestMapping("/")
//	public String viewHomePage(Model model) {
//		List<Product> listProducts = productService.listAll();
//		model.addAttribute("listProducts", listProducts);
//		
//		return "index"; // index.html
//	}
//	
//	@RequestMapping("/new")
//	public String showNewProductPage(Model model) {
//		Product product = new Product();
//		model.addAttribute("product", product);
//		
//		return "new_product"; //new_product.html
//	}
//	
//	@RequestMapping(value = "/save", method = RequestMethod.POST)
//	public String saveProduct(@ModelAttribute("product") Product product) {
//		productService.saveProduct(product);
//		// returns to home page which shows table data, Edit and Delete links
//		return "redirect:/";// redirects to localhost:8087/  -- home page
//	}
//	
//	@RequestMapping("/edit/{id}")
//	public ModelAndView showEditProductPage(@PathVariable(name = "id") int id) {
//		ModelAndView mav = new ModelAndView("edit_product");
//		Product product = productService.getProductById(id);
//		mav.addObject("product", product);
//		
//		return mav;
//	}
//	
//	@RequestMapping("/delete/{id}")
//	public String deleteProduct(@PathVariable(name = "id") int id) {
//		productService.deleteProduct(id);
//		// returns to home page which shows table data, Edit and Delete links
//		return "redirect:/";
//	}
//}
//
