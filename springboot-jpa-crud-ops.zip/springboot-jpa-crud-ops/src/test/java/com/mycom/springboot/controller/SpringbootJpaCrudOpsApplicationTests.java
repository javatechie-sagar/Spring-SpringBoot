package com.mycom.springboot.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import com.mycom.springboot.MockBookService;
import com.mycom.springboot.model.Book;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class SpringbootJpaCrudOpsApplicationTests {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    private MockBookService mockBookService;

    @BeforeEach
    public void setUp() {
        mockBookService = new MockBookService();
    }

    @Test
    public void testGetAllBooks() {
        List<Book> books = this.restTemplate.getForObject("http://localhost:" + port + "/api/v1/library/getallbooks", List.class);
        assertNotNull(books);
    }

    @Test
    public void testSaveBook() {
        Book book = new Book();
        book.setBookid(1);
        book.setBookname("Test Book");

        HttpEntity<Book> request = new HttpEntity<>(book);
        ResponseEntity<Integer> response = this.restTemplate.postForEntity("http://localhost:" + port + "/api/v1/library/addbook", request, Integer.class);

        assertEquals(1, response.getBody());
    }

    @Test
    public void testGetBookById() {
        Book book = new Book();
        book.setBookid(1);
        book.setBookname("Test Book");
        mockBookService.saveBook(book);

        Book retrievedBook = this.restTemplate.getForObject("http://localhost:" + port + "/api/v1/library/getbook/1", Book.class);
        assertNotNull(retrievedBook);
        assertEquals("Test Book", retrievedBook.getBookname());
    }

    @Test
    public void testUpdateBook() {
        Book book = new Book();
        book.setBookid(1);
        book.setBookname("Test Book");
        mockBookService.saveBook(book);

        book.setBookname("Updated Test Book");
        HttpEntity<Book> request = new HttpEntity<>(book);
        this.restTemplate.exchange("http://localhost:" + port + "/api/v1/library/updatebook", HttpMethod.PUT, request, Book.class);

        Book updatedBook = this.restTemplate.getForObject("http://localhost:" + port + "/api/v1/library/getbook/1", Book.class);
        assertEquals("Updated Test Book", updatedBook.getBookname());
    }

    @Test
    public void testDeleteBook() {
        Book book = new Book();
        book.setBookid(1);
        book.setBookname("Test Book");
        mockBookService.saveBook(book);

        this.restTemplate.delete("http://localhost:" + port + "/api/v1/library/deletebook/1");

        Book deletedBook = this.restTemplate.getForObject("http://localhost:" + port + "/api/v1/library/getbook/1", Book.class);
        assertEquals(null, deletedBook);
    }
}
