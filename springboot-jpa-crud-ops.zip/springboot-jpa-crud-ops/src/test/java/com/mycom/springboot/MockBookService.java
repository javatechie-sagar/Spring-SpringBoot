package com.mycom.springboot;

import java.util.ArrayList;
import java.util.List;

import com.mycom.springboot.model.Book;
import com.mycom.springboot.service.BookService;

public class MockBookService extends BookService {
    private List<Book> books = new ArrayList<>();

    @Override
    public List<Book> getAllBooks() {
        return books;
    }

    @Override
    public void saveBook(Book book) {
        books.add(book);
    }

    @Override
    public Book getBookById(int bookid) {
        return books.stream().filter(book -> book.getBookid() == bookid).findFirst().orElse(null);
    }

    @Override
    public void updateBook(Book book) {
        deleteBook(book.getBookid());
        saveBook(book);
    }

    @Override
    public void deleteBook(int bookid) {
        books.removeIf(book -> book.getBookid() == bookid);
    }
}
