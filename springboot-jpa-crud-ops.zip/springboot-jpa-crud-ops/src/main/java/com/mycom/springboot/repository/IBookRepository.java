package com.mycom.springboot.repository;
// For basic CRUD Operations - CrudRepository

import org.springframework.data.repository.CrudRepository;
//repository that extends CrudRepository
import org.springframework.stereotype.Repository;

import com.mycom.springboot.model.Book;
@Repository
public interface IBookRepository extends CrudRepository<Book, Integer> {
	
}
