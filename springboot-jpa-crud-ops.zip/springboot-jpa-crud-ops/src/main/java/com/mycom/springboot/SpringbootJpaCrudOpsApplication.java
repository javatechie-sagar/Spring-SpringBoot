package com.mycom.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorMvcAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
@EnableWebMvc
@ComponentScan(basePackages={"com.mycom.springboot.controller","com.mycom.springboot.service"})
@EnableAutoConfiguration(exclude = {ErrorMvcAutoConfiguration.class})

public class SpringbootJpaCrudOpsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootJpaCrudOpsApplication.class, args);
		System.out.println("Spring Boot Application Started..!");
	}

}
