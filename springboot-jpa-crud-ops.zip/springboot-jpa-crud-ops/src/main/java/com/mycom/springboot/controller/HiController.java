package com.mycom.springboot.controller;

import org.springframework.web.bind.annotation.GetMapping;

public class HiController {

	@GetMapping("/hi")
	private String getHello() {
		return "Hi, from Spring Boot!";
	}

}
