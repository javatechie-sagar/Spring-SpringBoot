package com.mycom.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.mycom.springboot.model.Book;
import com.mycom.springboot.repository.IBookJpaRepository;

@Service
public class BookJpaRepositoryService {

    @Autowired
    private IBookJpaRepository repo;

    // Pagination
    public Page<Book> getBooksWithPagination(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return repo.findAll(pageable);
    }

    // Sorting
    public List<Book> getBooksWithSorting(String field) {
        return repo.findAll(Sort.by(Sort.Direction.ASC, field));
    }

    // Pagination + Sorting
    public Page<Book> getBooksWithPaginationAndSorting(
    		int page, int size, String field) {
        Pageable pageable =
                PageRequest.of(page, size, Sort.by(field).descending());

        return repo.findAll(pageable);
    }

    // JPQL
    public List<Book> getExpensiveBooks(int price) {
        return repo.getExpensiveBooks(price);
    }

  
}