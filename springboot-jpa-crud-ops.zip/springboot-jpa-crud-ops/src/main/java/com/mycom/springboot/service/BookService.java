package com.mycom.springboot.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mycom.springboot.model.Book;
import com.mycom.springboot.repository.IBookRepository;

//defining the business logic
@Service
public class BookService {
	@Autowired
	IBookRepository booksRepository;

	// getting all books record by using the method findAll() of CrudRepository
	public List<Book> getAllBooks() {
		List<Book> bookList;
		bookList = (List<Book>) booksRepository.findAll();
		//findAll() method will be implemented at runtime.
		// This is known as dynamic method dispatch
		for (Book book : bookList) {
			System.out.println(book.getBookname());
			System.out.println("Book with id 101 exists..? T/F " + 
						booksRepository.existsById(101));
		}
		System.out.println("Number of rows " + booksRepository.count());
		return bookList;
	}
	// getting a specific row by using the method findById() of CrudRepository
	public Book getBookById(int id) {
		return booksRepository.findById(id).get();
	}
	// saving a specific record by using the method save() of CrudRepository
	public void saveBook(Book book) {
		booksRepository.save(book);
	}
	// updating a record
	public void updateBook(Book book) {
		booksRepository.save(book);
	}
	//deleting a specific record by using the method deleteById() of CrudRepository
	public void deleteBook(int id) {
		booksRepository.deleteById(id);
	}

}