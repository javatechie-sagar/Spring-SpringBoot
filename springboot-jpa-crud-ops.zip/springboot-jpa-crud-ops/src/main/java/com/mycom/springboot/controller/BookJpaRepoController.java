package com.mycom.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mycom.springboot.model.Book;
import com.mycom.springboot.service.BookJpaRepositoryService;

@RestController
@RequestMapping("/books")
public class BookJpaRepoController {

    @Autowired
    private BookJpaRepositoryService service;

    // Pagination
    @GetMapping("/pagination/{page}/{size}")
    public Page<Book> getBooksPagination(
            @PathVariable int page,
            @PathVariable int size) {

        return service.getBooksWithPagination(page, size);
    }

    // Sorting
    @GetMapping("/sorting/{field}")
    public List<Book> getBooksSorting(@PathVariable String field) {
        return service.getBooksWithSorting(field);
    }

    // Pagination + Sorting
    @GetMapping("/paginationAndSort/{page}/{size}/{field}")
    public Page<Book> getBooksPaginationAndSort(
            @PathVariable int page,
            @PathVariable int size,
            @PathVariable String field) {

        return service.getBooksWithPaginationAndSorting(page, size, field);
    }

    // JPQL
    @GetMapping("/expensive/{price}")
    public List<Book> expensiveBooks(@PathVariable int price) {
        return service.getExpensiveBooks(price);
    }

    
}
