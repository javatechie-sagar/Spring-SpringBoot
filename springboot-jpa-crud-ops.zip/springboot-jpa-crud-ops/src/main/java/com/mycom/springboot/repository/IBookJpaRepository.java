package com.mycom.springboot.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.mycom.springboot.model.Book;

public interface IBookJpaRepository extends JpaRepository<Book, Integer> {

    // Derived Query Methods
    List<Book> findByAuthor(String author);

    List<Book> findByPriceGreaterThan(int price);

    List<Book> findByBooknameContaining(String keyword);

    // Sorting
    List<Book> findByAuthor(String author, Sort sort);

    // Pagination
    Page<Book> findByAuthor(String author, Pageable pageable);

    // JPQL Query
    @Query("SELECT b FROM Book b WHERE b.price > :price")
    List<Book> getExpensiveBooks(int price);

    
}