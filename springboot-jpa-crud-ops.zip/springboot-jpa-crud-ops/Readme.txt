JPA Repository - REST End Points :

URLs
Pagination:
	GET http://localhost:8087/books/pagination/0/3

	***Page 0 with 3 records.

Sorting:
	GET http://localhost:8087/books/sorting/price


Sort fields can be:

 bookid
 bookname
 author
 price

Pagination + Sorting
	GET http://localhost:8087/books/paginationAndSort/0/5/price

JPQL Query - To get books data of those price is > 300
	GET http://localhost:8087/books/expensive/300

Native Query
	GET http://localhost:8087/books/native/Rod Johnson